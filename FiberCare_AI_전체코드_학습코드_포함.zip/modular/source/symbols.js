/* 교육용 기본 세탁 기호의 사진 비교 시제품. 다양한 사진 환경에서 정확도 검증 전. */
(function(){'use strict';
const tub='<path d="M17 39 Q27 34 36 39 T55 39 T74 39 T93 39 L86 87 Q55 101 24 87 Z"/>';
const triangle='<path d="M55 17 103 95 H7Z"/>';
const square='<rect x="12" y="12" width="86" height="86" rx="1"/>';
const iron='<path d="M19 79 H101 L89 95 H18Z M28 79 V55 Q27 38 48 37 H71 Q91 39 94 56 V79Z"/>';
const circ='<circle cx="55" cy="55" r="43"/>';
const xmark='<path d="M22 20 90 92 M90 20 22 92" stroke-width="7"/>';
const def={
 wash30:{label:'30℃ 이하 물세탁 기호',family:'wash',inner:tub+'<text x="55" y="77" font-size="27" fill="black" stroke="none" font-family="Arial, sans-serif" font-weight="700">30</text>',explain:'표시된 30℃를 넘기지 않는 물세탁의 최대 온도입니다. 기호 아래 선 등 추가 표시도 확인하세요.',rule:'wash30'},
 wash40:{label:'40℃ 이하 물세탁 기호',family:'wash',inner:tub+'<text x="55" y="77" font-size="27" fill="black" stroke="none" font-family="Arial, sans-serif" font-weight="700">40</text>',explain:'표시된 40℃를 넘기지 않는 물세탁의 최대 온도입니다. 기호 아래 선 등 추가 표시도 확인하세요.',rule:'wash40'},
 wash60:{label:'60℃ 이하 물세탁 기호',family:'wash',inner:tub+'<text x="55" y="77" font-size="27" fill="black" stroke="none" font-family="Arial, sans-serif" font-weight="700">60</text>',explain:'표시된 60℃를 넘기지 않는 물세탁의 최대 온도입니다. 기호 아래 선 등 추가 표시도 확인하세요.',rule:'wash60'},
 washNo:{label:'물세탁 금지 기호',family:'wash',inner:tub+xmark,explain:'물세탁 금지 표시입니다. 제품의 전문 세탁 표시를 확인하세요.',rule:'washNo'},
 bleachYes:{label:'표백 허용 기호',family:'bleach',inner:triangle,explain:'삼각형은 표백 관련 표시입니다. 제품에 다른 표백 제한이 없는지 확인하세요.',rule:'bleachYes'},
 bleachNo:{label:'표백 금지 기호',family:'bleach',inner:triangle+xmark,explain:'표백제를 사용하지 마세요.',rule:'bleachNo'},
 tumbleLow:{label:'저온 회전식 건조 기호',family:'dry',inner:square+'<circle cx="55" cy="55" r="31"/><circle cx="55" cy="55" r="4" fill="black" stroke="none"/>',explain:'회전식 건조기 저온 설정 표시입니다. 다른 기호와 제품 상태를 함께 확인하세요.',rule:'tumbleLow'},
 tumbleNormal:{label:'일반 회전식 건조 기호',family:'dry',inner:square+'<circle cx="55" cy="55" r="31"/><circle cx="44" cy="55" r="4" fill="black" stroke="none"/><circle cx="66" cy="55" r="4" fill="black" stroke="none"/>',explain:'회전식 건조기 일반 온도 설정 표시입니다.',rule:'tumbleNormal'},
 tumbleNo:{label:'회전식 건조 금지 기호',family:'dry',inner:square+'<circle cx="55" cy="55" r="31"/>'+xmark,explain:'회전식 건조기를 사용하지 마세요.',rule:'tumbleNo'},
 ironLow:{label:'저온 다림질 기호',family:'iron',inner:iron+'<circle cx="55" cy="63" r="3.5" fill="black" stroke="none"/>',explain:'저온 다림질 표시입니다. 세부 온도는 제품 표시에 따라 확인하세요.',rule:'ironLow'},
 ironMedium:{label:'중온 다림질 기호',family:'iron',inner:iron+'<circle cx="48" cy="63" r="3.5" fill="black" stroke="none"/><circle cx="62" cy="63" r="3.5" fill="black" stroke="none"/>',explain:'중온 다림질 표시입니다. 제품 관리 지침을 함께 확인하세요.',rule:'ironMedium'},
 ironNo:{label:'다림질 금지 기호',family:'iron',inner:iron+xmark,explain:'다림질을 하지 마세요.',rule:'ironNo'},
 cleanYes:{label:'전문 드라이클리닝 기호',family:'professional',inner:circ+'<text x="55" y="72" font-size="50" fill="black" stroke="none" font-family="Arial, sans-serif" font-weight="700">P</text>',explain:'전문 세탁에 관한 표시입니다. 해당 용제 및 제한 조건은 기호 전체를 확인해야 합니다.',rule:'cleanYes'},
 cleanNo:{label:'드라이클리닝 금지 기호',family:'professional',inner:circ+xmark,explain:'드라이클리닝 금지 표시입니다.',rule:'cleanNo'}
};
const ids=Object.keys(def),svgFor=id=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 110 110" width="110" height="110"><rect width="110" height="110" fill="white"/><g stroke="#000" stroke-width="6.5" stroke-linejoin="round" stroke-linecap="round" fill="none">${def[id].inner}</g></svg>`;
function getImg(src){return new Promise((res,rej)=>{const im=new Image();im.onload=()=>res(im);im.onerror=()=>rej(new Error('세탁 기호 예시 이미지를 생성할 수 없습니다.'));im.src=src;})}
function bitmapFromImage(im){const c=document.createElement('canvas');c.width=c.height=180;const ctx=c.getContext('2d',{willReadFrequently:true});ctx.fillStyle='#fff';ctx.fillRect(0,0,180,180);const w=im.naturalWidth||im.width,h=im.naturalHeight||im.height;if(!w||!h)throw Error('이미지를 읽을 수 없습니다.');const k=Math.min(176/w,176/h);ctx.drawImage(im,(180-w*k)/2,(180-h*k)/2,w*k,h*k);const d=ctx.getImageData(0,0,180,180).data;const gs=[];for(let i=0;i<180*180;i++)gs.push((d[i*4]*.299+d[i*4+1]*.587+d[i*4+2]*.114));const corners=[gs[0],gs[179],gs[179*180],gs[180*180-1]].sort((a,b)=>a-b);const dark=corners[1]<100;const fg=new Uint8Array(180*180);let count=0;for(let i=0;i<gs.length;i++){fg[i]=dark?(gs[i]>130?1:0):(gs[i]<165?1:0);count+=fg[i]};if(count<60||count>gs.length*.52)throw Error('기호가 뚜렷하지 않습니다. 밝은 바탕에 기호 하나만 가까이 찍어 주세요.');
 let minX=179,minY=179,maxX=0,maxY=0;for(let y=3;y<177;y++)for(let x=3;x<177;x++)if(fg[y*180+x]){minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y)}
 const bw=maxX-minX+1,bh=maxY-minY+1;if(bw<12||bh<12)throw Error('세탁 기호가 너무 작게 보입니다.');let out=new Uint8Array(48*48);let k2=Math.min(40/bw,40/bh),ow=bw*k2,oh=bh*k2,x0=(48-ow)/2,y0=(48-oh)/2;for(let y=0;y<48;y++)for(let x=0;x<48;x++){const sx=Math.round(minX+(x-x0)/k2),sy=Math.round(minY+(y-y0)/k2);if(sx>=minX&&sx<=maxX&&sy>=minY&&sy<=maxY)out[y*48+x]=fg[sy*180+sx]}
 return out;}
function similar(a,b){let an=0,bn=0,ac=0,bc=0,intersection=0;const n=48;for(let i=0;i<n*n;i++){if(a[i]&&b[i])intersection++;if(a[i]){an++; const y=(i/n)|0,x=i%n;let hit=false;for(let yy=Math.max(0,y-1);yy<=Math.min(n-1,y+1)&&!hit;yy++)for(let xx=Math.max(0,x-1);xx<=Math.min(n-1,x+1);xx++)if(b[yy*n+xx]){hit=true;break;}if(hit)ac++;}if(b[i]){bn++;const y=(i/n)|0,x=i%n;let hit=false;for(let yy=Math.max(0,y-1);yy<=Math.min(n-1,y+1)&&!hit;yy++)for(let xx=Math.max(0,x-1);xx<=Math.min(n-1,x+1);xx++)if(a[yy*n+xx]){hit=true;break;}if(hit)bc++;}}const p=ac/Math.max(1,an),r=bc/Math.max(1,bn);const soft=2*p*r/Math.max(1e-6,p+r);const exact=intersection/Math.max(1,an+bn-intersection);return .68*exact+.32*soft;}
let templates=null;
async function init(){if(templates)return templates;const result={};for(const id of ids){const img=await getImg('data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svgFor(id)));result[id]=bitmapFromImage(img)}templates=result;return result;}
async function analyze(im){const base=bitmapFromImage(im),ts=await init();const candidates=ids.map(id=>({id,label:def[id].label,score:similar(base,ts[id])})).sort((a,b)=>b.score-a.score);return {best:candidates[0],second:candidates[1],candidates,identified:candidates[0].score>=.57&&candidates[0].score-candidates[1].score>=.012};}
window.FiberSymbol={def,ids,svgFor,analyze,init};
})();

# FiberCare AI — 전체 소스코드 (사용자 업로드 index(8).html 기준)

이 자료는 사용자가 업로드한 `index(8).html`에서 **코드를 직접 추출**하고, 이전 FiberCare AI 학습 프로젝트에 있던 Python 스크립트를 별도 수록한 것입니다.

## 파일 설명

- `index.html` — 업로드된 파일을 **글자 하나 수정하지 않고 그대로 복사**한 단일 파일 웹서비스. CSS·JavaScript·학습된 모델 값이 모두 들어 있습니다. GitHub Pages에 이 파일 **하나만** `index.html`이라는 이름으로 올려도 됩니다.
- `modular/index.html` — **동일한 화면 코드**를 CSS/JavaScript 파일로 분리한 버전(검토·학습용). GitHub Pages에 배포하려면 `modular` 폴더 **안의** `index.html`과 `source` 폴더를 함께 저장소 루트에 업로드하세요.
- `modular/source/style.css` — 웹사이트 디자인 및 모바일·iPad 반응형 스타일.
- `modular/source/model.js` — 학습 완료한 KNN/CNN 모델의 **수치 데이터**와 파라미터. 5MB 이상이라 길지만 코드가 손상된 것이 아닙니다.
- `modular/source/inference.js` — RGB/LBP/방향성 특징 계산 및 KNN/CNN 추론 함수.
- `modular/source/symbols.js` — 의류 세탁 기호의 기본 이미지 템플릿 비교 기능.
- `modular/source/app.js` — 사진 업로드, 미리보기, 분석 버튼, 소재별 관리 정보, OCR, 결과 출력 등 웹서비스 동작 코드.
- `training/train.py` — TextileClass-7 ZIP을 읽고 데이터를 분리하여 기본 KNN/CNN을 학습·평가하는 **이전 학습 프로젝트의 Python 스크립트**.
- `training/train_multiscale.py` — 다중 반경 특징 KNN을 선택하여 모델을 갱신하는 **이전 학습 프로젝트의 Python 스크립트**.
- `training/make_charts.py` — 학습 결과 그래프와 CSV를 만드는 Python 스크립트.
- `results/metrics.json`, `results/model_results.csv`, `results/data_counts.csv` — 이전 학습 프로젝트에서 저장된 모델 결과/가공 데이터. 사용자가 첨부한 HTML 파일에는 원본 학습 기록을 실행하는 과정 자체는 포함되어 있지 않습니다.

## 즉시 배포 방법

1. 저장소에 **루트의 `index.html`** 파일을 업로드합니다.
2. 저장소 `Settings → Pages → Deploy from a branch → main / (root)`를 선택합니다.
3. 웹사이트의 카메라·사진 선택·결과 출력을 테스트합니다. 모바일 파일 미리보기에서는 JavaScript나 파일 선택이 차단될 수 있으니 **배포된 HTTPS 주소**에서 테스트합니다.

## 학습 재현 (선택 사항)

Python 3에서 `numpy`, `pillow`, `scikit-learn`, `torch`, `matplotlib` 등이 필요합니다. 원본 이미지 데이터셋 ZIP은 이 소스 ZIP에 포함하지 않았습니다(별도 제공된 TextileClass-7 ZIP 사용).

```bash
python -m pip install numpy pillow scikit-learn torch matplotlib
python training/train.py "TextileClass-7 Dataset for Fabric Material Classif(1).zip" output
python training/train_multiscale.py "TextileClass-7 Dataset for Fabric Material Classif(1).zip" output
python training/make_charts.py output
```

- `train.py`를 먼저, `train_multiscale.py`를 뒤에 실행합니다.
- 재학습 시 모델 갱신이 필요하면 학습 결과 `output/model.js`가 단일 파일 `index.html`의 맨 앞 첫 번째 `<script>window.FIBER_MODEL=...;</script>`에 대응합니다. **단순히 학습 파일만 GitHub에 올린다고 웹사이트의 모델이 자동 변경되지는 않습니다.**
- 이 스크립트와 데이터셋으로 결과를 독립적으로 재현하려면 Python 환경과 의존성 설치 및 재학습 실행이 필요합니다. 이 패키지를 만들면서 재학습을 다시 실행한 것은 아닙니다.

## 정확성·출처에 관한 주의

- 사용자 업로드 HTML은 실제 코드 그대로 제공하며, `modular` 버전은 코드 구조를 이해하기 쉽도록 분리한 것입니다.
- 학습 코드는 **기존 프로젝트 ZIP에서 회수한 스크립트**이며 업로드된 HTML에서 추출한 것은 아닙니다. 모델 데이터가 이전 학습 ZIP의 `model.js`와 일치하는지는 파일 비교로 확인했습니다.
- 옷감의 외관만으로 정확한 섬유 혼용률이나 제조사 세탁 지침을 판단할 수 없으며, 웹사이트는 교육용 시제품입니다.
- 성분표 OCR 기능은 외부 Tesseract.js와 언어 데이터를 인터넷으로 내려받으므로 완전히 오프라인인 단일 파일은 아닙니다.
- 웹사이트 `index.html` 자체는 Python 서버가 아니라 정적 HTML/CSS/JavaScript로 작동합니다.

학습 데이터 출처: TextileClass-7 Version 2, Mendeley Data, https://doi.org/10.17632/m2h53zr39s.2

import json, pathlib, sys, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib import font_manager
p=pathlib.Path(sys.argv[2] if len(sys.argv)>2 else '.');w=pathlib.Path(sys.argv[1]);m=json.loads((w/'metrics.json').read_text());names=['면','면 혼방','폴리에스터','울','실크','비스코스'];font_path=pathlib.Path('/usr/share/fonts/truetype/nanum/NanumGothic.ttf');
if font_path.exists(): font_manager.fontManager.addfont(str(font_path))
plt.rcParams.update({'font.family':'NanumGothic','axes.unicode_minus':False,'font.size':12,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':140});dest=p/'charts';dest.mkdir(exist_ok=True)
def save(fig,n):fig.text(.02,.015,'출처: TextileClass-7 v2 [5] · 직접 학습 및 분석',fontsize=9,color='#465c55');fig.tight_layout(rect=[0,.035,1,1]);fig.savefig(dest/n,dpi=180,bbox_inches='tight');plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4.5));b=np.zeros(6);colors=['#34796a','#9ac1b0','#e9ba70'];
for s,c,l in zip(['train','valid','test'],colors,['학습','검증','테스트']):a=np.array(m['counts'][s]);ax.bar(names,a,bottom=b,label=l,color=c);b+=a
for i,v in enumerate(b):ax.text(i,v+12,str(int(v)),ha='center',fontsize=10)
ax.set(title='소재별 실제 학습·검증·테스트 이미지 수',ylabel='이미지 수 (장)',ylim=(0,max(b)*1.17));ax.legend(ncols=3,loc='upper right');save(fig,'counts.png')
fig,ax=plt.subplots(figsize=(7,4.4));x=np.arange(2);width=.32
for i,(s,l,c) in enumerate([('valid','검증','#9ac1b0'),('test','테스트','#34796a')]):vals=[m['metrics'][k][s]['accuracy']*100 for k in ['knn','cnn']];bars=ax.bar(x+(i-.5)*width,vals,width,label=l,color=c);ax.bar_label(bars,fmt='%.1f%%',padding=3)
ax.set_xticks(x,['KNN','소형 CNN']);ax.set(title='AI 모델 정확도 비교',ylabel='정확도 (%)',ylim=(0,100));ax.legend();save(fig,'accuracy.png')
fig,ax=plt.subplots(figsize=(7,5.4));mat=np.array(m['metrics'][m['selected']]['test']['confusion']);im=ax.imshow(mat,cmap='Greens',vmin=0);ax.set_xticks(range(6),names,rotation=25,ha='right');ax.set_yticks(range(6),names);ax.set(title=f"{m['selected'].upper()} 테스트 혼동행렬 (n={mat.sum()})",xlabel='AI 예측',ylabel='원본 정답');
for i in range(6):
 for j in range(6):ax.text(j,i,str(mat[i,j]),ha='center',va='center',color='white' if mat[i,j]>mat.max()*.55 else '#172e28')
fig.colorbar(im,ax=ax,shrink=.8,label='이미지 수');save(fig,'confusion.png')
fig,ax=plt.subplots(figsize=(7,4.5));h=m['history'];ax.plot([a['epoch'] for a in h],[a['train_accuracy']*100 for a in h],'-o',label='학습 정확도',color='#34796a');ax.plot([a['epoch'] for a in h],[a['valid_accuracy']*100 for a in h],'-o',label='검증 정확도',color='#d89e4d');ax.axvline(m['best_epoch'],ls='--',color='#8c8c8c',label='최종 CNN epoch');ax.set(title='소형 CNN 학습 곡선',xlabel='학습 횟수 (epoch)',ylabel='정확도 (%)',ylim=(0,100));ax.legend();save(fig,'learning.png')
# Three actual preprocessed attributes, averaged by class, rather than made-up data.
f=np.load(w/'features.npz');F=f['train_features'];Y=f['train_labels'];fig,axs=plt.subplots(3,1,figsize=(9,9));cols=['#34796a','#d89e4d','#728eae','#8d719d','#c16960','#637d58'];
for i in range(6):
 a=F[Y==i].mean(0);axs[0].plot(range(8),a[:8],'-o',label=names[i],color=cols[i]);lbpstart=26 if m.get('knn_kind')=='multiscale' else 24;axs[1].plot(range(10),a[lbpstart:lbpstart+10],'-o',color=cols[i]);axs[2].plot(np.arange(8)*22.5,a[lbpstart+10:lbpstart+18],'-o',color=cols[i]);
axs[0].set(title='RGB 가공 예시: R 채널의 평균 색상 히스토그램',xlabel='색상 구간 (0~7)',ylabel='픽셀 비율');axs[0].legend(ncol=3,fontsize=9);axs[1].set(title='LBP 국소 질감 특징 (반경 1)',xlabel='이진 패턴 구간',ylabel='빈도 비율');axs[2].set(title='방향성 가공: 밝기 변화 방향 히스토그램 (반경 1)',xlabel='방향 구간 시작 (도)',ylabel='가중 빈도 비율');save(fig,'features.png')
# Machine-readable table of original and used counts, and actual metrics.
import csv
with (p/'data_counts.csv').open('w',encoding='utf-8-sig',newline='') as out:
 wr=csv.writer(out);wr.writerow(['class','raw_train','raw_valid','raw_test','used_train','used_valid','used_test']);
 for i,k in enumerate(m['labels']):wr.writerow([k,*[m['raw'][s][k] for s in ['train','valid','test']],*[m['counts'][s][i] for s in ['train','valid','test']]])
 wr.writerow(['Denim',*[m['raw'][s]['Denim'] for s in ['train','valid','test']],0,0,0])
with (p/'model_results.csv').open('w',encoding='utf-8-sig',newline='') as out:
 wr=csv.writer(out);wr.writerow(['model','split','n','correct','accuracy','macro_f1','accepted','accepted_correct']);
 for k,q in m['metrics'].items():
  for s,v in q.items():wr.writerow([k,s,*[v[j] for j in ['n','correct','accuracy','macro_f1','accepted','accepted_correct']]])

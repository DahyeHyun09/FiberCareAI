import sys,io,zipfile,collections,json,hashlib,pathlib
import numpy as np
from PIL import Image
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score,f1_score,confusion_matrix,classification_report
import torch
from torch import nn
from torch.utils.data import TensorDataset,DataLoader
OUT=pathlib.Path(sys.argv[2]);OUT.mkdir(exist_ok=True,parents=True)
np.random.seed(2026);torch.manual_seed(2026);torch.set_num_threads(4)
LABELS=['cotton','cotton_mixed','polyester','wool','silk','viscose']; MAPPING=dict(zip(['Cotton','Cotton MIxed','Polyester','Wool','Silk','Viscose'],LABELS));SIZE=64
z=zipfile.ZipFile(sys.argv[1]); nested=[n for n in z.namelist() if n.endswith('.zip')];z=zipfile.ZipFile(io.BytesIO(z.read(nested[0]))) if nested else z
raw=collections.Counter();groups={s:set() for s in ['train','valid','test']}; hashes={s:set() for s in groups};data={s:[] for s in groups};excluded=collections.Counter();rows=[]
for n in sorted(z.namelist()):
 p=n.split('/')
 if len(p)!=3 or p[0] not in groups or not n.lower().endswith('.jpg'):continue
 s,c,_=p;raw[s,c]+=1
 if c not in MAPPING:continue
 b=z.read(n);g=p[-1].split('.rf.')[0];h=hashlib.sha256(b).hexdigest();rows.append((s,c,n,g,h,b))
for s in ['test','valid','train']:
 for split,c,n,g,h,b in rows:
  if split!=s:continue
  if any(g in groups[k] or h in hashes[k] for k in groups if k!=s) or h in hashes[s]:excluded[s]+=1;continue
  try:im=np.array(Image.open(io.BytesIO(b)).convert('RGB').resize((SIZE,SIZE),Image.Resampling.BILINEAR))
  except Exception:excluded[s]+=1;continue
  groups[s].add(g);hashes[s].add(h);data[s].append((im,LABELS.index(MAPPING[c]),n))
print('counts',{s:len(v) for s,v in data.items()},'removed',excluded,flush=True)
X={s:np.stack([v[0] for v in a]) for s,a in data.items()};Y={s:np.array([v[1] for v in a]) for s,a in data.items()}
def features(im):
 a=im.astype(np.float64)/255;f=[]
 for c in range(3):f.extend(np.bincount(np.minimum((a[:,:,c]*8).astype(int),7).ravel(),minlength=8)/4096)
 g=(im.astype(np.int32)@np.array([299,587,114]))/255000;mid=g[1:-1,1:-1];nei=[g[:-2,:-2],g[:-2,1:-1],g[:-2,2:],g[1:-1,2:],g[2:,2:],g[2:,1:-1],g[2:,:-2],g[1:-1,:-2]];bits=np.stack([v>=mid for v in nei]);cnt=bits.sum(0);transitions=(bits!=np.roll(bits,1,axis=0)).sum(0);b=np.where(transitions<=2,cnt,9);f.extend(np.bincount(b.ravel(),minlength=10)/mid.size)
 dx=g[1:-1,2:]-g[1:-1,:-2];dy=g[2:,1:-1]-g[:-2,1:-1];mag=np.hypot(dx,dy);ang=np.mod(np.arctan2(dy,dx),np.pi);bins=np.minimum((ang*8/np.pi).astype(int),7);hist=np.bincount(bins.ravel(),weights=mag.ravel(),minlength=8);f.extend(hist/max(hist.sum(),1e-9));f.extend([g.mean(),g.std()]);return np.array(f)
F={s:np.stack([features(a) for a in xx]) for s,xx in X.items()};sc=StandardScaler().fit(F['train']);Z={s:sc.transform(f) for s,f in F.items()}
kn=None;best=-1
for k in [3,5,9,15]:
 m=KNeighborsClassifier(n_neighbors=k,weights='distance',n_jobs=2).fit(Z['train'],Y['train']);v=f1_score(Y['valid'],m.predict(Z['valid']),average='macro')
 if v>best:best=v;kn=m
print('KNN validation',best,'k',kn.n_neighbors,flush=True)
class Net(nn.Module):
 def __init__(self):
  super().__init__();self.convs=nn.Sequential(nn.Conv2d(3,12,3,padding=1),nn.ReLU(),nn.AvgPool2d(2),nn.Conv2d(12,24,3,padding=1),nn.ReLU(),nn.AvgPool2d(2),nn.Conv2d(24,32,3,padding=1),nn.ReLU(),nn.AvgPool2d(4));self.fc=nn.Linear(32*4*4,6)
 def forward(self,x):return self.fc(self.convs(x).flatten(1))
net=Net();opt=torch.optim.AdamW(net.parameters(),lr=.003);loss=nn.CrossEntropyLoss();T={s:torch.from_numpy(a).permute(0,3,1,2).float()/255 for s,a in X.items()};YY={s:torch.from_numpy(a) for s,a in Y.items()};loader=DataLoader(TensorDataset(T['train'],YY['train']),batch_size=96,shuffle=True,generator=torch.Generator().manual_seed(2026));hist=[];best=-1;best_state=None
@torch.no_grad()
def evalnet(s):
 net.eval();logits=torch.cat([net(t) for t in T[s].split(128)]);return logits.numpy(),float(loss(logits,YY[s]))
for epoch in range(10):
 net.train();total=0;hit=0
 for xx,yy in loader:
  opt.zero_grad();logits=net(xx);l=loss(logits,yy);l.backward();opt.step();total+=float(l.detach())*len(yy);hit+=int((logits.argmax(1)==yy).sum())
 v,vl=evalnet('valid');vf=f1_score(Y['valid'],v.argmax(1),average='macro');va=accuracy_score(Y['valid'],v.argmax(1));hist.append(dict(epoch=epoch+1,train_loss=total/len(Y['train']),train_accuracy=hit/len(Y['train']),valid_loss=vl,valid_accuracy=va,valid_f1=vf));print('epoch',epoch+1,round(va,3),round(vf,3),flush=True)
 if vf>best:best=vf;best_state={k:v.clone() for k,v in net.state_dict().items()};best_epoch=epoch+1
net.load_state_dict(best_state)
models={'knn':{s:kn.predict_proba(Z[s]) for s in ['valid','test']},'cnn':{s:torch.softmax(torch.from_numpy(evalnet(s)[0]),dim=1).numpy() for s in ['valid','test']}};metrics={}
for name,values in models.items():
 metrics[name]={}
 for s,probs in values.items():
  pred=probs.argmax(1);scores=np.sort(probs,axis=1);accepted=(scores[:,-1]>=.75)&(scores[:,-1]-scores[:,-2]>=.20);metrics[name][s]=dict(accuracy=float(accuracy_score(Y[s],pred)),macro_f1=float(f1_score(Y[s],pred,average='macro')),correct=int((pred==Y[s]).sum()),n=len(pred),confusion=confusion_matrix(Y[s],pred,labels=range(6)).tolist(),per_class=classification_report(Y[s],pred,labels=range(6),target_names=LABELS,output_dict=True,zero_division=0),accepted=int(accepted.sum()),accepted_correct=int(((pred==Y[s])&accepted).sum()))
selected=max(metrics,key=lambda k:metrics[k]['valid']['macro_f1']);print('selected',selected,'metrics',[(k,m['test']['accuracy']) for k,m in metrics.items()],flush=True)
base=dict(labels=LABELS,size=SIZE,selected=selected,knn=dict(k=kn.n_neighbors,mean=sc.mean_.tolist(),scale=sc.scale_.tolist(),features=np.round(Z['train'],7).tolist(),y=Y['train'].tolist()),cnn={k:v.numpy().tolist() for k,v in best_state.items()});(OUT/'model.js').write_text('window.FIBER_MODEL='+json.dumps(base,separators=(',',':'))+';\n')
result=dict(labels=LABELS,raw={s:{MAPPING.get(c,c):n for (sp,c),n in raw.items() if sp==s} for s in groups},counts={s:np.bincount(Y[s],minlength=6).tolist() for s in groups},excluded=dict(excluded),unique_filename_groups={s:len(g) for s,g in groups.items()},selected=selected,best_epoch=best_epoch,k=kn.n_neighbors,history=hist,metrics=metrics,thresholds=[.75,.20]);(OUT/'metrics.json').write_text(json.dumps(result,indent=2));(OUT/'metrics.js').write_text('window.FIBER_METRICS='+json.dumps(result,separators=(',',':'))+';\n')
fixtures=[]
for i in range(6):
 idx=int(np.where(Y['test']==i)[0][0]);a=X['test'][idx];fixtures.append(dict(rgb=a.ravel().tolist(),label=LABELS[i],cnn=models['cnn']['test'][idx].tolist(),knn=models['knn']['test'][idx].tolist(),filename=data['test'][idx][2]));Image.fromarray(a).save(OUT/f'example-{LABELS[i]}.png')
(OUT/'fixtures.json').write_text(json.dumps(fixtures,separators=(',',':')));np.savez_compressed(OUT/'features.npz',**{f'{s}_features':F[s] for s in F},**{f'{s}_labels':Y[s] for s in Y})

# Run after train.py with the same input and output directories.
import pathlib,sys
src=pathlib.Path(__file__).with_name('train.py').read_text();exec(src[:src.index('def features(im):')].replace('SIZE=64','SIZE=112'))
import math
# Multiple scales retain finer textile patterns; use grayscale differences and normalized histograms.
def feat(im):
 n=len(im);a=im.astype(np.float64)/255;f=[]
 for c in range(3):f.extend(np.bincount(np.minimum((a[:,:,c]*8).astype(int),7).ravel(),minlength=8)/(n*n))
 g=(im.astype(np.int32)@np.array([299,587,114]))/255000
 f.extend([g.mean(),g.std()])
 for radius in [1,2,4,8]:
  r=radius;mid=g[r:-r,r:-r];size=len(mid);nei=[g[:size,:size],g[:size,r:r+size],g[:size,2*r:],g[r:r+size,2*r:],g[2*r:,2*r:],g[2*r:,r:r+size],g[2*r:,:size],g[r:r+size,:size]];bits=np.stack([v>=mid for v in nei]);cnt=bits.sum(0);tr=(bits!=np.roll(bits,1,axis=0)).sum(0);bb=np.where(tr<=2,cnt,9);f.extend(np.bincount(bb.ravel(),minlength=10)/mid.size)
  dx=nei[3]-nei[7];dy=nei[5]-nei[1];mag=np.hypot(dx,dy);ang=np.mod(np.arctan2(dy,dx),np.pi);bins=np.minimum((ang*8/np.pi).astype(int),7);hist=np.bincount(bins.ravel(),weights=mag.ravel(),minlength=8);f.extend(hist/max(hist.sum(),1e-9));f.extend([mag.mean(),mag.std()])
 return np.array(f)
F={s:np.stack([feat(a) for a in xx]) for s,xx in X.items()};sc=StandardScaler().fit(F['train']);Z={s:sc.transform(f) for s,f in F.items()}; best=-1;kn=None
for k in [1,3,5,9,15,25]:
 for power in [1,2]:
  model=KNeighborsClassifier(n_neighbors=k,weights='distance',p=power,n_jobs=2).fit(Z['train'],Y['train']);v=f1_score(Y['valid'],model.predict(Z['valid']),average='macro');print(k,power,v,flush=True)
  if k>=3 and v>best:best=v;kn=model
result=json.loads((OUT/'metrics.json').read_text());base=json.loads((OUT/'model.js').read_text()[len('window.FIBER_MODEL='):-2]); print('multiscale best',best,flush=True)
result['baseline_knn_validation_f1']=result.get('baseline_knn_validation_f1',result['metrics']['knn']['valid']['macro_f1']); result['multiscale_knn_validation_f1']=best
if best>result['baseline_knn_validation_f1']:
 base['knn']=dict(k=kn.n_neighbors,p=kn.p,kind='multiscale',mean=sc.mean_.tolist(),scale=sc.scale_.tolist(),features=np.round(Z['train'],7).tolist(),y=Y['train'].tolist());result['k']=kn.n_neighbors;result['knn_p']=kn.p; result['knn_kind']='multiscale';result['knn_feature_count']=len(sc.mean_)
 for s in ['valid','test']:
  probs=kn.predict_proba(Z[s]);pred=probs.argmax(1);scores=np.sort(probs,axis=1);accepted=(scores[:,-1]>=.75)&(scores[:,-1]-scores[:,-2]>=.20);result['metrics']['knn'][s]=dict(accuracy=float(accuracy_score(Y[s],pred)),macro_f1=float(f1_score(Y[s],pred,average='macro')),correct=int((pred==Y[s]).sum()),n=len(pred),confusion=confusion_matrix(Y[s],pred,labels=range(6)).tolist(),per_class=classification_report(Y[s],pred,labels=range(6),target_names=LABELS,output_dict=True,zero_division=0),accepted=int(accepted.sum()),accepted_correct=int(((pred==Y[s])&accepted).sum()))
 fixtures=[]
 for i in range(6):
  # First test image in each class, not cherry-picked.
  idx=int(np.where(Y['test']==i)[0][0]);a=X['test'][idx];fixtures.append(dict(rgb=a.ravel().tolist(),label=LABELS[i],knn=kn.predict_proba(Z['test'][idx:idx+1])[0].tolist(),filename=data['test'][idx][2]));Image.fromarray(a).save(OUT/f'example-{LABELS[i]}.png')
 (OUT/'fixtures_multiscale.json').write_text(json.dumps(fixtures,separators=(',',':')));np.savez_compressed(OUT/'features.npz',**{f'{s}_features':F[s] for s in F},**{f'{s}_labels':Y[s] for s in Y})
 (OUT/'model.js').write_text('window.FIBER_MODEL='+json.dumps(base,separators=(',',':'))+';\n')
result['selected']=max(result['metrics'],key=lambda k:result['metrics'][k]['valid']['macro_f1']);(OUT/'metrics.json').write_text(json.dumps(result,indent=2));(OUT/'metrics.js').write_text('window.FIBER_METRICS='+json.dumps(result,separators=(',',':'))+';\n');print('final',result['selected'],result['metrics']['knn']['test']['accuracy'],flush=True)
